package org.clinic.database_config;
// definicja operacji na bazie
public class HibernateConfiguration {
}
